import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public products:any=[]
  public productIndex:number = 0;
  public add(name:any, price:any, company:any, image:any){
   /* let Name=name.value;
    let Price=price.value;
    let Company=company.value;
    let Image="/assets/images/"+image.value;*/
    this.products.push({ pid : ++this.productIndex, Name:name.value, Price:price.value, Company:company.value, Image:"/assets/images/"+image.value})
  }
  public delete(pid:any){
   // console.log(id.value);
   this.products=this.products.filter((prod:any)=>prod.pid!=pid)
   
  }
  public change(p:any,imageUpdate:any){
    p.Image="/assets/images/"+imageUpdate.value
  }
}

