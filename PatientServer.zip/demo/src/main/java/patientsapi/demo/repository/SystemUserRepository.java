package patientsapi.demo.repository;



import org.springframework.data.mongodb.repository.MongoRepository;

import patientsapi.demo.Model.SystemUser;

public interface SystemUserRepository extends MongoRepository<SystemUser, String>{
	public SystemUser findByEmail(String email);
    
}
