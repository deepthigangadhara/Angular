package patientsapi.demo.Model;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
public class SystemUser {
    @Id
	private String userId;

	private String name;
	private String email;
	private String password;	
	private String roles;
	private Boolean isActive;
    
}
