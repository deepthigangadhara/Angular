package patientsapi.demo.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import patientsapi.demo.Model.SystemUser;
import patientsapi.demo.repository.SystemUserRepository;

@Service
public class SystemUserService {
    @Autowired
	private SystemUserRepository userRepository;
	
	public SystemUser saveUser(SystemUser user) 
	{
		try {
			user.setRoles("ROLE_ADMIN");
			user.setIsActive(true);
			userRepository.insert(user);		
			return user;
		}catch(Exception ex) {
			return null;
		}
	}
	public SystemUser getById(String userid) 
	{
		return userRepository.findById(userid).get();	
	}
	public SystemUser getByEmail(String email) 
	{
		return userRepository.findByEmail(email);		
	}
}
