class student{
    private roll: number;
    private name: String;
    private age: number;
    private marks: number;

    public constructor(roll:number=undefined, name:String=undefined, age:number=undefined, marks:number=undefined){
        this.roll=roll
        this.name=name
        this.age=age
        this.marks=marks
    }

    public show(): void{
        console.log("\nRoll: ", this.roll)
        console.log("Name: ", this.name)
        console.log("Age: ", this.age)
        console.group("Marks: ", this.marks)
    }
}
var ob1=new student(101, "Deepthi", 21, 70)
var ob2=new student()
ob1.show();
ob2.show();