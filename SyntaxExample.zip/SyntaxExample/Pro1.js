var student = /** @class */ (function () {
    function student(roll, name, age, marks) {
        if (roll === void 0) { roll = undefined; }
        if (name === void 0) { name = undefined; }
        if (age === void 0) { age = undefined; }
        if (marks === void 0) { marks = undefined; }
        this.roll = roll;
        this.name = name;
        this.age = age;
        this.marks = marks;
    }
    student.prototype.show = function () {
        console.log("\nRoll: ", this.roll);
        console.log("Name: ", this.name);
        console.log("Age: ", this.age);
        console.group("Marks: ", this.marks);
    };
    return student;
}());
var ob1 = new student(101, "Deepthi", 21, 70);
var ob2 = new student();
ob1.show();
ob2.show();
