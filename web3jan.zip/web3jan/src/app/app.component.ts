import { Component } from '@angular/core';
//import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public title:String="Good Afternoon !"
  public names=["Vikas", "Rajesh", "Meera","Ajay"]
  public change(){
    this.title="Good Night !"
  }
 /* public msg:String= "Hello All !"

  public send(frm:NgForm)
  {
    console.log(frm.value)
  }*/
}

