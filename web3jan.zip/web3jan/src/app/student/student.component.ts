import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

 /* private roll : number;
  private name:String;
  private age: number;
  private marks:number;
  /* public getRoll():number{return this.roll}
   public getName():String{ return this.name}
   public getAge():number{return this.age}
   public getMarks():number{return this.marks}

   public setRoll(roll:number){this.roll=roll}
   public setName(name:String){ this.name=name}
   public setAge(age:number){this.age=age}
   public setMarks(marks:number){this.marks=marks}

  constructor(roll:number, name:String, age:number, marks:number) { 
    this.roll=roll
    this.name=name
    this.age=age
    this.marks=marks
  }*/
 public student=[{roll:101,name:"vikas", age:19, marks:79},{roll:102, name:"Rajesh", age:20, marks:80}]
  ngOnInit(): void {
  }
  public add(t1:any, t2:any, t3:any, t4:any){
  /* let roll=t1.value*1
    let name=t2.value
    let age=t3.value*1
    let marks=t4.value*1
    this.student.push({roll, name, age, marks})*/
    this.student.push({roll:t1.value, name:t2.value, age:t3.value, marks: t4.value})
    
  }

}
