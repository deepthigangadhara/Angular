import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {

  public num=[44,35,66,46,23,36,37,69,20]

  constructor() { }

  ngOnInit(): void {
  }

}
